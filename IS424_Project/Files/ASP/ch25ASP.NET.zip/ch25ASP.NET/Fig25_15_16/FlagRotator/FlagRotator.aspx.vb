
Partial Class FlagRotator
   Inherits System.Web.UI.Page

End Class
