The folder MyDocuments_VisualStudio2005_Projects contains the solution directory for this Web application that Visual Web Developer created in the folder 

	My Documents\Visual Studio 2005\Projects

